// age=18
// if(age>=18){
//     document.write("eligible for job<br>")
// }
// else{
//       document.write("not eligible for job")                                  
// }
// maths=45
// if(maths>40){
//    document.write("pass<br>")                                     
// }
// else{
//     document.write("fail")                                    
// }

// x=prompt("enter your amount")
// if(x=6000){
//     document.write(x-x*40/100)
// }
// else{
//     document.write(x)
// }
// a=prompt("enter your no.")
// if(a>0){
//     document.write("positive no.")
// }
// else{
//     document.write("negetive no.")
// }
// 
// 
// a=9
// b=4
// c=0
// if(a>b){
//     if(c>b){
//         document.write("b is smaller")
//     }
//     else{
//         document.write("a is greater<br>")
//     }
// }
// else{
//     document.write("c is greater<br>")
// }
//
// switch(0){
//     case 0:
//         document.write("4.9")
//         break
//     case 1:
//         document.write("0.1")
//         break
//     case 2:
//         document.write("4")
//         break
//     default:
//         document.write("indevild number")    
        
// }
// a=parseInt(prompt("enter your number"))
// switch(a){
//     case 1:
//         document.write("monday")
//         break
//     case 2:
//         document.write("Tuesday")
//         break
//     case 3:
//         document.write("wednesday")
//         break
//     case 4:
//         Document.write("thrusday")
//         break
//     case 5:
//         document.write("friday")
//         break
//     case 6:
//         document.write("saturday")
//         break
//     case 7:
//         document.write("sunday")      
//         break
//     default:
//         document.write("indivial number")          

// }
b=parseInt(prompt("enter your colour"))
switch(b){
    case 1:
        document.write("pink")
        break
    case 2:
        document.write("blue")
        break
    case 3:
        document.write("red")
        break
    case 4:
        document.write("yellow")
        break
    case 5:
        document.write("purple")
        break
    case 6:
        document.write("sky blue")    
        break
    default:
        document.write("invalid number")          
} 
